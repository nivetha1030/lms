<div class="img-fluid w-100 text-center">
	<img style="opacity: 1; width: 100px;" src="<?php echo base_url('assets/backend/images/file-search.svg'); ?>"><br>
	<?php echo get_phrase('choose_an_option_from_the_left_side'); ?>
</div>
